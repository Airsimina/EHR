const data = {
  data: [
    { type: 1, startDate: '2019/12/23 15:00', endDate: '2019/12/23 15:00', sum: '1', status: 1 },
    { type: 2, startDate: '2019/12/23 15:00', endDate: '2019/12/23 15:00', sum: '1', status: 2 },
    { type: 3, startDate: '2019/12/23 15:00', endDate: '2019/12/23 15:00', sum: '1', status: 3 }
  ]
}
export default data