/***
 *  vuex 模块 created by lcx
 */

const market = {
    namespaced: true,
    state: {
        // isLegal: false
    },
    mutations: {
        // CHANGE_ISLEGAL: (state, value) => {
        //     state.isLegal = value
        // }
    },
    getters: {
        // GET_ISLEGAL: (state, getters) => {
        //     return state.isLegal
        // }
    }
}

export default market