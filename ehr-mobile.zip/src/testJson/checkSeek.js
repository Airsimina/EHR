const data = {
  formData: {
    compassionateLeave: 0,
    annualLeave: 0,
    funeralLeave: 0,
    maternityLeave: 0,
    injuryLeave: 0,
    nursingLeave: 0,
    sickLeave: 0,
    marriageLeave: 0
  },
  list: [{
    subList: [],
    title: '2020-01'
  }],
  resp_code: 0,
  resp_msg: ''
}
export default data
