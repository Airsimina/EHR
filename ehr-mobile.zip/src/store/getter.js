export default {
    getInfoData: (state, getters) => {
        return state.infoData
    },
    getInfoDataList: (state, getters) => {
        return state.infoDataList
    }

}